package es.antonborri.home_widget_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
